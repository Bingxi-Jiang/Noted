from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from .audio_utils import (
    analyze_audio_file,
    browser_stats_from_form,
    cleanup_temp_file,
    looks_like_noise_text,
    merge_audio_stats,
    normalize_text,
    save_audio_chunk,
    should_reject_audio,
    write_temp_audio,
)
from .config import APP_TITLE, AUDIO_DIR, DB_PATH, DATA_DIR, TRANSCRIBE_LANGUAGE, TRANSCRIBE_LANGUAGE_MODE
from .db import create_session_id, ensure_session, ensure_storage_dirs, get_conn, init_db, utc_now_iso
from .html_page import HTML_PAGE
from .models import AskRequest, NewSessionRequest, SummaryRequest
from .openai_client import get_client
from .retrieval import build_context_block, retrieve_raw_chunks, retrieve_summaries
from .services.summary_service import maybe_create_summary
from .services.transcription_service import transcribe_file

app = FastAPI(title=APP_TITLE)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return HTML_PAGE


@app.post("/api/session/new")
def new_session(payload: NewSessionRequest) -> Dict[str, str]:
    session_id = create_session_id()
    ensure_session(session_id, payload.title)
    return {"session_id": session_id, "title": payload.title or session_id}


@app.get("/api/session/{session_id}")
def get_session(session_id: str) -> Dict[str, Any]:
    with get_conn() as conn:
        session = conn.execute(
            "SELECT session_id, title, created_at FROM sessions WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        if session is None:
            raise HTTPException(status_code=404, detail="Session not found")
        chunks = conn.execute(
            """
            SELECT id, chunk_index, text, created_at, status, reject_reason, duration_ms, rms_dbfs,
                   channels, frame_rate, sample_width, audio_path, capture_mode, language_mode
            FROM transcripts WHERE session_id = ? ORDER BY chunk_index ASC
            """,
            (session_id,),
        ).fetchall()
        summaries = conn.execute(
            """
            SELECT id, summary_index, start_chunk_index, end_chunk_index, text, created_at
            FROM summaries WHERE session_id = ? ORDER BY summary_index ASC
            """,
            (session_id,),
        ).fetchall()
    return {
        "session": dict(session),
        "storage": {
            "data_dir": str(DATA_DIR),
            "db_path": str(DB_PATH),
            "audio_dir": str(AUDIO_DIR / session_id),
        },
        "transcripts": [dict(row) for row in chunks],
        "summaries": [dict(row) for row in summaries],
    }


@app.post("/api/transcribe")
async def transcribe_audio(
    session_id: str = Form(...),
    capture_mode: str = Form("mic"),
    audio_stats_json: str | None = Form(None),
    audio: UploadFile = File(...),
) -> Dict[str, Any]:
    ensure_session(session_id)

    content_type = (audio.content_type or "").lower()
    filename = audio.filename or "audio.webm"
    suffix = Path(filename).suffix.lower()
    if not suffix:
        if "wav" in content_type:
            suffix = ".wav"
        elif "mp4" in content_type or "m4a" in content_type:
            suffix = ".m4a"
        elif "mpeg" in content_type or "mp3" in content_type:
            suffix = ".mp3"
        elif "ogg" in content_type:
            suffix = ".ogg"
        else:
            suffix = ".webm"

    audio_bytes = await audio.read()
    if not audio_bytes:
        raise HTTPException(status_code=400, detail="Empty audio file")

    with get_conn() as conn:
        row = conn.execute(
            "SELECT COALESCE(MAX(chunk_index), -1) AS max_idx FROM transcripts WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        next_idx = int(row["max_idx"]) + 1

    tmp_path = None
    try:
        tmp_path = write_temp_audio(audio_bytes, suffix)
        server_stats = analyze_audio_file(tmp_path)
        browser_stats = browser_stats_from_form(audio_stats_json)
        stats = merge_audio_stats(server_stats, browser_stats)

        reject_audio, reject_reason = should_reject_audio(stats)
        if reject_audio:
            return {
                "ok": True,
                "stored": False,
                "filtered": True,
                "filter_reason": reject_reason,
                "audio_stats": stats,
                "capture_mode": capture_mode,
                "language_mode": f"{TRANSCRIBE_LANGUAGE_MODE}:{TRANSCRIBE_LANGUAGE}",
            }

        text = normalize_text(transcribe_file(tmp_path))
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Transcription failed for {suffix} audio ({content_type or 'unknown content type'}): {exc}",
        ) from exc
    finally:
        cleanup_temp_file(tmp_path)

    reject_text, reject_reason = looks_like_noise_text(text)
    if reject_text:
        return {
            "ok": True,
            "stored": False,
            "filtered": True,
            "filter_reason": reject_reason,
            "text": text,
            "audio_stats": stats,
            "capture_mode": capture_mode,
            "language_mode": f"{TRANSCRIBE_LANGUAGE_MODE}:{TRANSCRIBE_LANGUAGE}",
        }

    audio_path = save_audio_chunk(session_id, next_idx, suffix, audio_bytes)
    with get_conn() as conn:
        conn.execute(
            """
            INSERT INTO transcripts(
                session_id, chunk_index, text, created_at, audio_path, status, reject_reason,
                duration_ms, rms_dbfs, channels, frame_rate, sample_width, capture_mode, language_mode
            ) VALUES (?, ?, ?, ?, ?, 'accepted', NULL, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session_id,
                next_idx,
                text,
                utc_now_iso(),
                str(audio_path),
                stats.get("duration_ms"),
                stats.get("rms_dbfs"),
                stats.get("channels"),
                stats.get("frame_rate"),
                stats.get("sample_width"),
                capture_mode,
                f"{TRANSCRIBE_LANGUAGE_MODE}:{TRANSCRIBE_LANGUAGE}",
            ),
        )
        conn.commit()

    summary = maybe_create_summary(session_id)
    return {
        "ok": True,
        "stored": True,
        "filtered": False,
        "chunk_index": next_idx,
        "text": text,
        "audio_path": str(audio_path),
        "db_path": str(DB_PATH),
        "audio_stats": stats,
        "capture_mode": capture_mode,
        "language_mode": f"{TRANSCRIBE_LANGUAGE_MODE}:{TRANSCRIBE_LANGUAGE}",
        "summary_created": summary,
    }


@app.post("/api/summary")
def create_summary(payload: SummaryRequest) -> Dict[str, Any]:
    ensure_session(payload.session_id)
    return {"ok": True, "summary": maybe_create_summary(payload.session_id)}


@app.post("/api/ask")
def ask_question(payload: AskRequest) -> Dict[str, Any]:
    question = normalize_text(payload.question)
    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty")

    with get_conn() as conn:
        session = conn.execute(
            "SELECT session_id FROM sessions WHERE session_id = ?",
            (payload.session_id,),
        ).fetchone()
        if session is None:
            raise HTTPException(status_code=404, detail="Session not found")

    raw_rows = retrieve_raw_chunks(payload.session_id, question)
    summary_rows = retrieve_summaries(payload.session_id, question)
    if not raw_rows and not summary_rows:
        return {"answer": "This session has no transcript yet.", "citations": [], "used_chunks": []}

    context_parts: List[str] = []
    if summary_rows:
        context_parts.append("Session summaries:\n" + build_context_block(summary_rows, "summary"))
    if raw_rows:
        context_parts.append("Transcript chunks:\n" + build_context_block(raw_rows, "chunk"))
    context_text = "\n\n".join(context_parts)

    system_prompt = (
        "You answer questions only using the provided transcript evidence from one session. "
        "The session is primarily English but can contain short multilingual phrases. "
        "Do not normalize, translate, or erase multilingual snippets unless the user asks. "
        "If the evidence is insufficient, say that clearly. Cite chunk numbers and summary ranges when useful."
    )
    user_prompt = (
        f"Question:\n{question}\n\n"
        f"Evidence:\n{context_text}\n\n"
        "Answer based only on the evidence above."
    )

    try:
        client = get_client()
        response = client.responses.create(
            model="gpt-5.4-mini",
            input=[
                {"role": "system", "content": [{"type": "input_text", "text": system_prompt}]},
                {"role": "user", "content": [{"type": "input_text", "text": user_prompt}]},
            ],
        )
        answer = normalize_text(getattr(response, "output_text", "") or "")
        if not answer:
            raise ValueError("Empty model response")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"QA failed: {exc}") from exc

    citations = [f"chunk {row['chunk_index']}" for row in raw_rows]
    citations.extend(
        f"summary {row['summary_index']} ({row['start_chunk_index']}-{row['end_chunk_index']})" for row in summary_rows
    )
    return {
        "answer": answer,
        "citations": citations,
        "used_chunks": [dict(row) for row in raw_rows],
        "used_summaries": [dict(row) for row in summary_rows],
    }


if __name__ == "__main__":
    import uvicorn

    ensure_storage_dirs()
    print(f"[storage] data_dir={DATA_DIR}")
    print(f"[storage] db_path={DB_PATH}")
    print(f"[storage] audio_dir={AUDIO_DIR}")
    print(f"[transcribe] language_mode={TRANSCRIBE_LANGUAGE_MODE}:{TRANSCRIBE_LANGUAGE}")
    uvicorn.run("voice_rag_stage2.app:app", host="0.0.0.0", port=8000, reload=True)
