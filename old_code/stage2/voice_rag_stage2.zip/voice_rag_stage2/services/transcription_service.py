from typing import Any, Dict, Optional

from ..config import MODEL_TRANSCRIBE, TRANSCRIBE_LANGUAGE, TRANSCRIBE_LANGUAGE_MODE, TRANSCRIBE_PROMPT
from ..openai_client import get_client


def choose_language_arg() -> Optional[str]:
    if TRANSCRIBE_LANGUAGE_MODE == "force":
        return TRANSCRIBE_LANGUAGE
    return None


def transcribe_file(tmp_path: str) -> str:
    client = get_client()
    request_args: Dict[str, Any] = {
        "model": MODEL_TRANSCRIBE,
        "prompt": TRANSCRIBE_PROMPT,
    }
    language = choose_language_arg()
    if language:
        request_args["language"] = language

    with open(tmp_path, "rb") as audio_file:
        request_args["file"] = audio_file
        transcription = client.audio.transcriptions.create(**request_args)

    text = getattr(transcription, "text", None)
    if text is None and isinstance(transcription, dict):
        text = transcription.get("text")
    if text is None:
        raise ValueError("Transcription returned no text")
    return str(text)
