import json
import os
import re
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from pydub import AudioSegment

from .config import AUDIO_DIR, MAX_SILENCE_DBFS, MIN_AUDIO_MS, MIN_TRANSCRIPT_CHARS, NOISE_EXACT_TEXTS


def save_audio_chunk(session_id: str, chunk_index: int, suffix: str, audio_bytes: bytes) -> Path:
    session_audio_dir = AUDIO_DIR / session_id
    session_audio_dir.mkdir(parents=True, exist_ok=True)
    chunk_path = session_audio_dir / f"chunk_{chunk_index:06d}{suffix}"
    chunk_path.write_bytes(audio_bytes)
    return chunk_path


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def alpha_ratio(text: str) -> float:
    meaningful = [c for c in text if not c.isspace()]
    if not meaningful:
        return 0.0
    alpha_num = sum(1 for c in meaningful if c.isalnum())
    return alpha_num / len(meaningful)


def looks_like_noise_text(text: str) -> Tuple[bool, Optional[str]]:
    t = normalize_text(text)
    if t.lower() in NOISE_EXACT_TEXTS or t in NOISE_EXACT_TEXTS:
        return True, "noise_text"
    if len(t) < MIN_TRANSCRIPT_CHARS:
        return True, "too_short_text"
    if alpha_ratio(t) < 0.25 and len(t) <= 6:
        return True, "low_signal_text"
    if re.fullmatch(r"([a-zA-Z哈啊哦嗯呃]{1,2})\1{2,}", t):
        return True, "repetitive_text"
    return False, None


def _safe_float(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except Exception:
        return None


def _safe_int(value: Any) -> Optional[int]:
    try:
        if value is None or value == "":
            return None
        return int(value)
    except Exception:
        return None


def browser_stats_from_form(raw_json: Optional[str]) -> Dict[str, Any]:
    if not raw_json:
        return {
            "duration_ms": None,
            "rms_dbfs": None,
            "channels": None,
            "frame_rate": None,
            "sample_width": None,
            "source": "missing",
        }
    try:
        parsed = json.loads(raw_json)
        return {
            "duration_ms": _safe_int(parsed.get("duration_ms")),
            "rms_dbfs": _safe_float(parsed.get("rms_dbfs")),
            "channels": _safe_int(parsed.get("channels")),
            "frame_rate": _safe_int(parsed.get("frame_rate")),
            "sample_width": _safe_int(parsed.get("sample_width")),
            "source": "browser",
        }
    except Exception:
        return {
            "duration_ms": None,
            "rms_dbfs": None,
            "channels": None,
            "frame_rate": None,
            "sample_width": None,
            "source": "invalid_browser_json",
        }


def analyze_audio_file(tmp_path: str) -> Dict[str, Any]:
    try:
        seg = AudioSegment.from_file(tmp_path)
        return {
            "duration_ms": len(seg),
            "rms_dbfs": float(seg.dBFS) if seg.rms > 0 else float("-inf"),
            "channels": seg.channels,
            "frame_rate": seg.frame_rate,
            "sample_width": seg.sample_width,
            "source": "server_decode",
        }
    except Exception as exc:
        return {
            "duration_ms": None,
            "rms_dbfs": None,
            "channels": None,
            "frame_rate": None,
            "sample_width": None,
            "source": f"server_decode_failed:{type(exc).__name__}",
        }


def merge_audio_stats(primary: Dict[str, Any], fallback: Dict[str, Any]) -> Dict[str, Any]:
    merged: Dict[str, Any] = {}
    for key in ["duration_ms", "rms_dbfs", "channels", "frame_rate", "sample_width"]:
        merged[key] = primary.get(key) if primary.get(key) is not None else fallback.get(key)
    merged["source"] = primary.get("source") if any(primary.get(k) is not None for k in ["duration_ms", "rms_dbfs", "channels", "frame_rate", "sample_width"]) else fallback.get("source")
    merged["server_source"] = primary.get("source")
    merged["browser_source"] = fallback.get("source")
    return merged


def should_reject_audio(stats: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
    duration_ms = stats.get("duration_ms")
    rms_dbfs = stats.get("rms_dbfs")
    if duration_ms is not None and duration_ms < MIN_AUDIO_MS:
        return True, "audio_too_short"
    if rms_dbfs == float("-inf"):
        return True, "audio_silence"
    if rms_dbfs is not None and rms_dbfs < MAX_SILENCE_DBFS:
        return True, "audio_too_quiet"
    return False, None


def write_temp_audio(audio_bytes: bytes, suffix: str) -> str:
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp.flush()
        return tmp.name


def cleanup_temp_file(tmp_path: Optional[str]) -> None:
    if tmp_path:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
